package model;

public class Ofertas {
	private String idcon;
	private String nome;
	private String segmento;
	private String titulo;
	private String descricao;
	
	public Ofertas() {
		super();
	}
	
	// Contrutores inicia automaticamente os objetos criados nesse construtor
			public Ofertas(String idcon, String nome,String segmento, String titulo, String descricao) {
				super();
				this.idcon = idcon;
				this.nome = nome;
				this.segmento = segmento;
				this.titulo = titulo;
				this.descricao = descricao;
			}


			public String getIdcon() {
				return idcon;
			}
			public void setIdcon(String idcon) {
				this.idcon = idcon;
			}
			public String getNome() {
				return nome;
			}
			public void setNome(String nome) {
				this.nome = nome;
			}
			public String getSegmento() {
				return segmento;
			}
			public void setSegmento(String segmento) {
				this.segmento = segmento;
			}
			public String getTitulo(String titulo) {
				return titulo;
			}
			public void setTitulo(String titulo) {
				this.titulo = titulo;
			}
			public String getDescricao(String descricao) {
				return descricao;
			}
			public void setDescricao(String descricao) {
				this.descricao = descricao;
			}
	
}
