package model;

public class Propaganda {
	private String idcon;
	private String titulo;
	private String Segmento;
	private String decricao;
	
	
	

	public Propaganda(String idcon, String titulo, String segmento, String decricao) {
		super();
		this.idcon = idcon;
		this.titulo = titulo;
		this.Segmento = segmento;
		this.decricao = decricao;
	}

	public Propaganda() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getIdcon() {
		return idcon;
	}
	public void setIdcon(String idcon) {
		this.idcon = idcon;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getSegmento() {
		return Segmento;
	}
	public void setSegmento(String segmento) {
		Segmento = segmento;
	}
	public String getDecricao() {
		return decricao;
	}
	public void setDecricao(String decricao) {
		this.decricao = decricao;
	}
	
}
