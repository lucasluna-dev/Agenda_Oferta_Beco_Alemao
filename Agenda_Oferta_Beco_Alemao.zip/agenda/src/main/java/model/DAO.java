package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DAO {
	//* Modulo de conex�o*//
	
	// 1 - Parametros de conex�o
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url  = "jdbc:mysql://127.0.0.1:3306/dbagenda?useTimezone=true&serverTimezone=UTC";
	
	private String user = "root";
	private String password = "ldjfkdjyskslcj";
	
	
	// 2 - M�todo de conex�o
	
	private Connection conectar() {
		Connection con = null;
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
			return con;
		} catch (Exception e) {
			System.out.println(e);
			return null;
			
		}
	}
	
	/*CRUD CREAT CONTATOS*/
	
	public void inserirContato(JavaBeans contato) {// passagem de parametro sem retorno
		String creat = "insert into contatos (nome,fone,email) values (?,?,?)";
		try {
			//abrir a conexao com o banco
			Connection con = conectar();
			//Preparar a query para execu��o do banco de dados
			PreparedStatement pst = con.prepareStatement(creat);
			//substituir os paramentros do ? pelo conteudo das variaveis do javabeas.
			pst.setString(1, contato.getNome());
			pst.setString(2, contato.getFone());
			pst.setString(3, contato.getEmail());
			// Executar a query enviando dados para o banco
			pst.executeUpdate();
			//ecerrar a conex�o com o banco
			con.close();
			
			
		} catch(Exception e) {
			System.out.println(e);
		}
	}
	
	
	//Crud read com array e metodo com retorno
	
	public ArrayList<JavaBeans> listarContatos(){
		//Criando um objeto para acessar a classe JavaBeans
		
		ArrayList<JavaBeans> contatos = new ArrayList<>();
		
		String read = "select * from contatos order by nome";
		try {
			
			//abrir a conexao com o banco
			
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(read);
			ResultSet rs = pst.executeQuery();
			//la�o de repeti��o ser� executado em quanto tiver contatos.
			while (rs.next()){
				// variaveis de apoio que recebem dados do banco
				String idcon = rs.getString(1);
				String nome = rs.getString(2);
				String fone = rs.getString(3);
				String email = rs.getString(4);
				// populando o arraylist
				contatos.add(new JavaBeans(idcon,nome,fone,email));// recebendo os dados do banco ( passo 5 do slide)
			}
			con.close();
			return contatos;
		} catch (Exception e) {
			System.err.println(e);
			return null;
		}
	}
	
	
	// CREAT PROPAGANDA
	public void inserirPropaganda(Propaganda gerarPRO) {// passagem de parametro sem retorno com o nome do objeto gerarPRO
		String creatpro = "insert into propaganda (titulo,segmento,descricao) values (?,?,?)";
		try {
			//abrir a conexao com o banco
			Connection con = conectar();
			//Preparar a query para execu��o do banco de dados
			PreparedStatement pst = con.prepareStatement(creatpro);
			//substituir os paramentros do ? pelo conteudo das variaveis do javabeas.
			pst.setString(1, gerarPRO.getTitulo());
			pst.setString(2, gerarPRO.getSegmento());
			pst.setString(3, gerarPRO.getDecricao());
			// Executar a query enviando dados para o banco
			pst.executeUpdate();
			//ecerrar a conex�o com o banco
			con.close();
			
			
		} catch(Exception e) {
			System.out.println(e);
		}
	}
	
	//Crud read com array e metodo com retorno
	
		public ArrayList<Propaganda> listarPropaganda(){
			//Criando um objeto para acessar a classe JavaBeans
			
			ArrayList<Propaganda> propagandas = new ArrayList<>();
			
			String read = "select * from propaganda order by Segmento";
			try {
				
				//abrir a conexao com o banco
				
				Connection con = conectar();
				PreparedStatement pst = con.prepareStatement(read);
				ResultSet rs = pst.executeQuery();
				//la�o de repeti��o ser� executado em quanto tiver contatos.
				while (rs.next()){
					// variaveis de apoio que recebem dados do banco
					String idcon = rs.getString(1);
					String titulo = rs.getString(2);
					String Segmento = rs.getString(3);
					String descricao = rs.getString(4);
					// populando o arraylist
					propagandas.add(new Propaganda(idcon,titulo,Segmento,descricao));// recebendo os dados do banco ( passo 5 )
				}
				con.close();
				return propagandas;
			} catch (Exception e) {
				System.err.println(e);
				return null;
			}
		}
	
	
	// CREAT Lancamento
		public void inserirLancamento(Lancamento gerarLancamento) {// passagem de parametro sem retorno com o nome do objeto gerarPRO
			String creatLacamento = "insert into lancamento (idFK_Pedido,EmailCliente,comida,decricaoPropaganda,dataLancamento,Titulo) values (?,?,?,?,?,?)";
			try {
				//abrir a conexao com o banco
				Connection con = conectar();
				//Preparar a query para execu��o do banco de dados
				PreparedStatement pst = con.prepareStatement(creatLacamento);
				//substituir os paramentros do ? pelo conteudo das variaveis do javabeas.
				pst.setString(1, gerarLancamento.getIdFK_Pedido());
				pst.setString(2, gerarLancamento.getEmailCliente());
				pst.setString(3, gerarLancamento.getComida());
				pst.setString(4, gerarLancamento.getdecricaoPropaganda());
				pst.setString(5, gerarLancamento.getDataLancamento());
				pst.setString(6, gerarLancamento.getTitulo());
				
				// Executar a query enviando dados para o banco
				pst.executeUpdate();
				//ecerrar a conex�o com o banco
				con.close();
				
				
			} catch(Exception e) {
				System.out.println(e);
			}
		}
		
		
		//Crud read com array e metodo com retorno
		
		public ArrayList<Lancamento> listarLancamento(){
			//Criando um objeto para acessar a classe JavaBeans
			
			ArrayList<Lancamento> Lancamentos = new ArrayList<>();
			
			String read = "select * from lancamento order by comida";
			try {
				
				//abrir a conexao com o banco
				
				Connection con = conectar();
				PreparedStatement pst = con.prepareStatement(read);
				ResultSet rs = pst.executeQuery();
				//la�o de repeti��o ser� executado em quanto tiver contatos.
				while (rs.next()){
					// variaveis de apoio que recebem dados do banco
					String idcon = rs.getString(1);
					String idFK_Pedido = rs.getString(2);
					String EmailCliente = rs.getString(3);
					String comida = rs.getString(4);
					String decricaoPropaganda = rs.getString(5);
					String dataLancamento = rs.getString(6);
					String Titulo = rs.getString(7);
					// populando o arraylist
					Lancamentos.add(new Lancamento(idcon,idFK_Pedido,EmailCliente,comida,decricaoPropaganda,dataLancamento,Titulo));// recebendo os dados do banco ( passo 5 )
				}
				con.close();
				return Lancamentos;
			} catch (Exception e) {
				System.err.println(e);
				return null;
			}
		}
	
		
		
		
		
	
	
	
	
	
	
	/*teste de conex�o
	 * 
	 * tive que tirar a instacia do controller //TESTE DE CONEXAO
		dao.testeConex�o();
	
	public void testeConex�o() {
		try {
			Connection con = conectar();
			System.out.println(con);
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}*/
}
