package model;

public class Lancamento {
	
	private String idcon;
	private String idFK_Pedido ;
	private String EmailCliente ;
	private String comida ;
	private String decricaoPropaganda ;
	private String dataLancamento ;
	private String Titulo ;
	
	
	public Lancamento() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Lancamento(String idcon, String idFK_Pedido, String emailCliente, String comida, String decricaoPropaganda,
			String dataLancamento, String Titulo) {
		super();
		this.idcon = idcon;
		this.idFK_Pedido = idFK_Pedido;
		this.EmailCliente = emailCliente;
		this.comida = comida;
		this.decricaoPropaganda = decricaoPropaganda;
		this.dataLancamento = dataLancamento;
		this.Titulo = Titulo;
	}
	
	public String getIdcon() {
		return idcon;
	}
	public void setIdcon(String idcon) {
		this.idcon = idcon;
	}
	public String getIdFK_Pedido() {
		return idFK_Pedido;
	}
	public void setIdFK_Pedido(String idFK_Pedido) {
		this.idFK_Pedido = idFK_Pedido;
	}
	public String getEmailCliente() {
		return EmailCliente;
	}
	public void setEmailCliente(String emailCliente) {
		EmailCliente = emailCliente;
	}
	public String getComida() {
		return comida;
	}
	public void setComida(String comida) {
		this.comida = comida;
	}
	public String getdecricaoPropaganda() {
		return decricaoPropaganda;
	}
	public void setdecricaoPropaganda(String decricaoPropaganda) {
		this.decricaoPropaganda = decricaoPropaganda;
	}
	public String getDataLancamento() {
		return dataLancamento;
	}
	public void setDataLancamento(String dataLancamento) {
		this.dataLancamento = dataLancamento;
	}
	
	public String getTitulo() {
		return Titulo;
	}
	public void setTitulo(String Titulo) {
		this.Titulo = Titulo;
	}
}


