package controller;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DAO;
import model.JavaBeans;// importando classes
import model.Propaganda;
import model.Lancamento;

@WebServlet(urlPatterns = {"/Controller", "/main", "/insert","/propaganda","/insertPro","/lancamento","/insertlancamento"})//insert para receber os dados do formulario.
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
    DAO dao = new DAO();
    JavaBeans contato = new JavaBeans(); // criando objeto da classe javaBeans para acesssar metodos publicos get e set
    Propaganda Propagandanova = new Propaganda(); // criando objeto da classe javaBeans para acesssar metodos publicos get e set
    Lancamento novoLancamento = new Lancamento();
    public Controller() {
        super();
        
    } 

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);
		if(action.equals("/main")){
			contatos(request, response);
		}else if(action.equals("/insert")) { // se conteudo da variavel action for insert vou redirecionar o metodo para encaminhar a requisi��o para models
			novoContato(request, response);
		}else if(action.equals("/propaganda")){
			propaganda(request, response);
		}else if(action.equals("/insertPro")){
			novaPropaganda(request, response);
		}else if(action.equals("/lancamento")) {
			lancamento(request, response);
		}else if(action.equals("/insertlancamento")){
			novoLancamento(request, response);
		}
		
		else {
			response.sendRedirect("index.html");
		}
	 }
	
	//listar contatos
	protected void contatos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Criando um objeto que ir� receber os dados do javabeans
		//tamb�m listando todos os contatos dao banco
		ArrayList<JavaBeans> lista = dao.listarContatos();
		
		//Encaminhar a lista ao documento agenda
		request.setAttribute("contato", lista);
		RequestDispatcher rd = request.getRequestDispatcher("agenda.jsp");
		rd.forward(request, response);
		
		//teste de recebimento da lista 
		for (int i = 0; i< lista.size(); i++) {
			System.out.println(lista.get(i).getIdcon()); 
			System.out.println(lista.get(i).getNome());
			System.out.println(lista.get(i).getFone());
			System.out.println(lista.get(i).getEmail());
			
		}
	}
	
	//Novo contato, nova camada criada na aula #11 - Parte 2/3
	protected void novoContato(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		// inserindo os valores dentro dos atributos e metodos da classe javaBeans que o nome do objeto do nome contato que foi instanciado .
		contato.setNome(request.getParameter("nome"));
		contato.setFone(request.getParameter("fone"));
		contato.setEmail(request.getParameter("email"));
		
		// invocar o m�todo inserirContato passando o objeto contato para a classe dao que tem conex�o com o banco de dados
		dao.inserirContato(contato);
		// redirecionar para o documento agenda.jsp depois de inserir os contatos
		response.sendRedirect("main");
		
		
		//response.sendRedirect("agenda.jsp");
		/*teste de recebimento dos dados do form
		System.out.println(request.getParameter("nome"));
		System.out.println(request.getParameter("fone"));
		System.out.println(request.getParameter("email"));*/
		
		
	}
	
	// Lista propaganda
	protected void propaganda(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Propaganda> lista = dao.listarPropaganda();
		request.setAttribute("Propagandanova", lista);
		RequestDispatcher rd = request.getRequestDispatcher("propaganda.jsp");
		rd.forward(request, response);
		

	}
	
	// PARTE DE PROPAGANDA ABAIXO
		protected void novaPropaganda(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			Propagandanova.setTitulo(request.getParameter("titulo"));
			Propagandanova.setSegmento(request.getParameter("segmento"));
			Propagandanova.setDecricao(request.getParameter("descricao"));
			
			// invocar o metodo inserirPropaganda e passando o objeto gerarPRO
			dao.inserirPropaganda(Propagandanova);
			response.sendRedirect("propaganda");
			
			
		}
		
		protected void lancamento(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			ArrayList<Lancamento> lista = dao.listarLancamento();
			request.setAttribute("novoLancamento", lista);
			RequestDispatcher rd = request.getRequestDispatcher("lancamento.jsp");
			rd.forward(request, response);
			
			
		}
		
		
		protected void novoLancamento(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			novoLancamento.setIdFK_Pedido(request.getParameter("idFK_Pedido"));
			novoLancamento.setEmailCliente(request.getParameter("emailcliente"));
			novoLancamento.setComida(request.getParameter("comida"));
			novoLancamento.setdecricaoPropaganda(request.getParameter("decricaoPropaganda"));
			novoLancamento.setDataLancamento(request.getParameter("datalancamento"));
			novoLancamento.setTitulo(request.getParameter("Titulo"));
			
			dao.inserirLancamento(novoLancamento);
			response.sendRedirect("lancamento.jsp");
		}
	

}
