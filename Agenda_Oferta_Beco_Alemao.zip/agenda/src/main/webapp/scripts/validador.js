/**
 * 
 */

 function validar(){
	 
	 let nome = frmContato.nome.value;
	 let fone = frmContato.fone.value;
	 let email = frmContato.email.value;
	 
	 if(nome === ""){
		 alert("Preencha o campo Nome");
		 frmContato.nome.focus();
		 return false
	 }else if (fone === ""){
		  alert("Preencha o campo Fone");
		 frmContato.fone.focus();
		 return false
	 }else if (email === ""){
		  alert("Preencha o campo E-mail");
		 frmContato.email.focus();
		 return false
	 }
	 else{
		 document.forms["frmContato"].submit()
	 }
	 
	 
 }
 
 
 
 function validarPropaganda(){
	 
	 let titulo = frmpropaganda.titulo.value;
	 let segmento = frmpropaganda.segmento.value;
	 let descricao = frmpropaganda.descricao.value;
	 
	 if(titulo === ""){
		 alert("Preencha o campo titulo");
		 frmpropaganda.titulo.focus();
		 return false
	 }else if (segmento === ""){
		  alert("Preencha o campo segmento");
		 frmpropaganda.segmento.focus();
		 return false
	 }else if (descricao === ""){
		  alert("Preencha o campo descricao");
		 frmpropaganda.descricao.focus();
		 return false
	 }
	 else{
		 document.forms["frmpropaganda"].submit()
	 }
	 
	 
 }
 

 

 
/*function validarLan(){
	alert("vasco");
	let Titulo = frmlancamento.Titulo.value;
	let EmailCliente = frmlancamento.EmailCliente.value;
	let comida = frmlancamento.comida.value;
	let decricaoPropaganda = frmlancamento.decricaoPropaganda.value;
	let dataLancamento = frmlancamento.dataLancamento.value;
	let idFK_Pedido = frmlancamento.idFK_Pedido.value;
	
	
	 
	 if(Titulo === ""){
		 alert("Preencha o campo Titulo");
		 frmpropaganda.Titulo.focus();
		 return false
	 }else if (EmailCliente === ""){
		  alert("Preencha o campo Email Cliente");
		 frmpropaganda.EmailCliente.focus();
		 return false
	 }else if (comida === ""){
		  alert("Preencha o campo comida");
		 frmpropaganda.comida.focus();
		 return false
	 }else if (decricaoPropaganda === ""){
		  alert("Preencha o campo decrição Propaganda");
		 frmpropaganda.decricaoPropaganda.focus();
		 return false
	 }else if (dataLancamento === ""){
		  alert("Preencha o campo data Lançamento");
		 frmpropaganda.dataLancamento.focus();
		 return false
	 }else if (idFK_Pedido === ""){
		  alert("Preencha o campo data idFK_Pedido");
		 frmpropaganda.idFK_Pedido.focus();
		 return false
	 }
	 
	 
	 else{
		 document.forms["frmlancamento"].submit()
	 }
	 
	 
 }*/
 